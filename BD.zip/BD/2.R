install.packages("party")

library(party)
data(iris)
print(head(iris))
str(iris)
iris_ctree <- ctree(Species ~ Sepal.Length + Sepal.Width + Petal.Length + Petal.Width, data = iris)
print(iris_ctree)
plot(iris_ctree)