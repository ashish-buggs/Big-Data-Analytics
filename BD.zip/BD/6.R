IQ <- rnorm(40, 30, 2)

IQ <- sort(IQ)

result <- c(0,0,0,1,0,0,0,0,0,1,
1,0,0,0,1,1,0,0,1,0,
0,0,1,0,0,1,1,0,1,1,
1,0,1,1,1,1,1,1,0,1)

df <- as.data.frame(cbind(IQ, result))

print(df)

plot(IQ, result,
xlab = "IQ Level",
ylab = "Probability of Passing")

g <- glm(result ~ IQ, family = binomial, data = df)

curve(predict(g, data.frame(IQ = x), type = "response"),
add = TRUE)

points(IQ, fitted(g), pch = 20)

summary(g)
